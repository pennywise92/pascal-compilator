package net.mips.compiler;

public class mainmips {

}
