package net.mips.compiler;

public class ErreurSemantique extends ErreurCompilation {
  public ErreurSemantique(CodesErr c) {
	  super(c.getMessage());
  }
}
