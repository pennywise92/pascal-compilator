package net.mips.compiler;
import java.io.IOException;
import java.io.File;
import java.io.FileWriter;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

import net.mips.interpreter.Instruction;
import net.mips.interpreter.Mnemonique;

public class ParserWS extends Parser {
	private ArrayList<Instruction> pcode;
    private PrintWriter fluxCible;

    public ArrayList<Instruction> getPcode() {
        return pcode;
    }

    public void setPcode(ArrayList<Instruction> pcode) {
        this.pcode = pcode;
    }

    public PrintWriter getFluxCible() {
        return fluxCible;
    }

    public void setFluxCible(PrintWriter fluxCible) {
        this.fluxCible = fluxCible;
        }
    
    public ParserWS(String nomf, OutputStream out) throws Exception {
        super(nomf);
        this.pcode = new ArrayList<>();
        this.scanner = new ScannerWS(nomf);

        this.fluxCible = new PrintWriter(out, true);

    }

    public void savePcode() {
        Mnemonique[] m = {Mnemonique.INT, Mnemonique.LDA, Mnemonique.LDI, Mnemonique.BRN , Mnemonique.BZE};
        if (!pcode.isEmpty()) {
        for (Instruction i : this.pcode) {
            
            
        }
        }

    }
    public void generer1(Mnemonique mne) {
        this.getPcode().add(new Instruction(mne));
    }
    
    public void generer2(Mnemonique mne, int n) {
        this.getPcode().add(new Instruction(mne, n));
    }

	
	public void testInsere(Tokens t, ClasseIdf cls, CodesErr c) 
			throws IOException, ErreurCompilation, ErreurSemantique {
		if (getScanner().getSymbCour().getToken()==t) {
			((ScannerWS)getScanner()).chercherSymb();
			if (((ScannerWS)getScanner()).getPlaceSymb()!=-1)
				throw new ErreurSemantique(CodesErr.DBL_DECL_ERR) ;
			((ScannerWS)getScanner()).entrerSymb(cls);
			getScanner().symbSuiv();
		}
		else
			throw new ErreurSyntaxique(c);
	}
	
	public void testCherche(Tokens t, CodesErr c) 
			throws IOException, ErreurCompilation {
		if (getScanner().getSymbCour().getToken()==t) {
			((ScannerWS)getScanner()).chercherSymb();
			int p=((ScannerWS)getScanner()).getPlaceSymb();
			if (p==-1)
				throw new ErreurSemantique(CodesErr.NON_DECL_ERR);
			Symboles s=((ScannerWS)getScanner()).getTableSymb().get(p);
			if (s.getClasse()==ClasseIdf.PROGRAMME)
				throw new ErreurSemantique(CodesErr.PROG_USE_ERR);
			
			getScanner().symbSuiv();
		}
		else
			throw new ErreurSyntaxique(c);
	}
	
	public void program() throws IOException, ErreurCompilation {
		testeAccept(Tokens.PROGRAM_TOKEN, CodesErr.PROGRAM_ERR);
		
		
		testInsere(Tokens.ID_TOKEN, ClasseIdf.PROGRAMME, CodesErr.ID_ERR);
		
		testeAccept(Tokens.PVIR_TOKEN, CodesErr.PVIR_ERR);
		block();
		this.generer1(Mnemonique.HLT);
		testeAccept(Tokens.PNT_TOKEN, CodesErr.PNT_ERR);
	}
	
	public void block() throws IOException, ErreurCompilation {
		consts();
		vars();
		insts();
	}
	
	public void consts() throws IOException, ErreurCompilation {
		switch(getScanner().getSymbCour().getToken()) {
		case CONST_TOKEN:
			getScanner().symbSuiv();
			testInsere(Tokens.ID_TOKEN,ClasseIdf.CONSTANTE,  CodesErr.ID_ERR);
			testeAccept(Tokens.EG_TOKEN, CodesErr.EG_ERR);
			testeAccept(Tokens.NUM_TOKEN, CodesErr.NUM_ERR);
			testeAccept(Tokens.PVIR_TOKEN, CodesErr.PVIR_ERR);
			while (getScanner().getSymbCour().getToken()==Tokens.ID_TOKEN) {
				testInsere(Tokens.ID_TOKEN,ClasseIdf.CONSTANTE,  CodesErr.ID_ERR);
				generer2(Mnemonique.LDA, ((ScannerWS) this.getScanner()).getOffset());
				testeAccept(Tokens.EG_TOKEN, CodesErr.EG_ERR);
				generer2(Mnemonique.LDI, Integer.parseInt(this.getScanner().getSymbCour().getNom()));
				testeAccept(Tokens.NUM_TOKEN, CodesErr.NUM_ERR);
				generer1(Mnemonique.STO);
				testeAccept(Tokens.PVIR_TOKEN, CodesErr.PVIR_ERR);
			}
			break;
		case VAR_TOKEN:
		
			break;
		case BEGIN_TOKEN:
			break;
		default:
			throw new ErreurSyntaxique(CodesErr.CONST_ERR);
		}
	}

	public void vars() throws IOException, ErreurCompilation {
		switch (getScanner().getSymbCour().getToken()) {
		case VAR_TOKEN:
			//var ID { , ID } ;
			getScanner().symbSuiv();
			testInsere(Tokens.ID_TOKEN,ClasseIdf.VARIABLE,  CodesErr.ID_ERR);
			generer2(Mnemonique.LDA, ((ScannerWS) this.getScanner()).getOffset());
			while (getScanner().getSymbCour().getToken()==Tokens.VIR_TOKEN){
				getScanner().symbSuiv();
				testInsere(Tokens.ID_TOKEN,ClasseIdf.VARIABLE,  CodesErr.ID_ERR);
			}
			testeAccept(Tokens.PVIR_TOKEN, CodesErr.PVIR_ERR);
			break;
		case BEGIN_TOKEN:
			break;
		default:
			throw new ErreurSyntaxique(CodesErr.VAR_ERR);
			
		}
	}
	
	public void affec() throws ErreurCompilation, IOException {
		testCherche(Tokens.ID_TOKEN, CodesErr.ID_ERR);
		generer2(Mnemonique.LDA, ((ScannerWS) this.getScanner()).getOffset());
		int p=((ScannerWS)getScanner()).getPlaceSymb();
		Symboles s=((ScannerWS)getScanner()).getTableSymb().get(p);
		if (s.getClasse()==ClasseIdf.CONSTANTE)
			throw new ErreurSemantique(CodesErr.CONST_MODIF_ERR);
		
		testeAccept(Tokens.AFFEC_TOKEN, CodesErr.AFFEC_ERR);
		expr();
		 generer1(Mnemonique.STO);
	}

	public void lire() throws ErreurCompilation, IOException {
		testeAccept(Tokens.READ_TOKEN, CodesErr.READ_ERR);
		testeAccept(Tokens.PARG_TOKEN, CodesErr.PARG_ERR);
		testCherche(Tokens.ID_TOKEN, CodesErr.ID_ERR);
		
		int p=((ScannerWS)getScanner()).getPlaceSymb();
		Symboles s=((ScannerWS)getScanner()).getTableSymb().get(p);
		if (s.getClasse()==ClasseIdf.CONSTANTE)
			throw new ErreurSemantique(CodesErr.CONST_MODIF_ERR);
		generer2(Mnemonique.LDA, ((ScannerWS) this.getScanner()).getPlaceSymb());
		generer1(Mnemonique.INN);
		while(getScanner().getSymbCour().getToken()==Tokens.VIR_TOKEN) {
			getScanner().symbSuiv();
			testCherche(Tokens.ID_TOKEN, CodesErr.ID_ERR);
			
			p=((ScannerWS)getScanner()).getPlaceSymb();
			s=((ScannerWS)getScanner()).getTableSymb().get(p);
			if (s.getClasse()==ClasseIdf.CONSTANTE)
				throw new ErreurSemantique(CodesErr.CONST_MODIF_ERR);
			generer2(Mnemonique.LDA, ((ScannerWS) this.getScanner()).getPlaceSymb());
			  generer1(Mnemonique.STO);
		}
		testeAccept(Tokens.PARD_TOKEN, CodesErr.PARD_ERR);
	}
	
	public void fact() throws IOException, ErreurCompilation {
		switch(getScanner().getSymbCour().getToken()) {
		case ID_TOKEN:
			testCherche(Tokens.ID_TOKEN,  CodesErr.ID_ERR);
			break;
		case NUM_TOKEN:
			getScanner().symbSuiv();
			break;
		case PARG_TOKEN:
			getScanner().symbSuiv();
			expr();
			testeAccept(Tokens.PARD_TOKEN, CodesErr.PARD_ERR);
		default:
			throw new ErreurSyntaxique(CodesErr.ID_ERR);
		}
	}
}

