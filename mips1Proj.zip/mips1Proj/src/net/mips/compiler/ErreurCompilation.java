package net.mips.compiler;

public class ErreurCompilation extends Exception{
    public ErreurCompilation(String message) {
        super(message);
    }
}
