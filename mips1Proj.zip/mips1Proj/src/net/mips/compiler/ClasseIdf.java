package net.mips.compiler;

public enum ClasseIdf {
	PROGRAMME,
    CONSTANTE,
    VARIABLE;
}
