package net.mips.compiler;
import java.io.*;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class Scanner {
   List<Symboles>MotsCles;
   public Symboles symbCour;
   public char carCour;
   public FileReader fluxSour;
public List<Symboles> getMotsCles() {
	return MotsCles;
}
public void setMotsCles(List<Symboles> motsCles) {
	MotsCles = motsCles;
}
public Symboles getSymbCour() {
	return symbCour;
}
public void setSymbCour(Symboles symbCour) {
	this.symbCour = symbCour;
}
public char getCarCour() {
	return carCour;
}
public void setCarCour(char carCour) {
	this.carCour = carCour;
}
public FileReader getFluxSour() {
	return fluxSour;
}
public void setFluxSour(FileReader fluxSour) {
	this.fluxSour = fluxSour;
}
public Scanner(List<Symboles> motsCles, Symboles symbCour, char carCour, FileReader fluxSour) {
	super();
	MotsCles = motsCles;
	this.symbCour = symbCour;
	this.carCour = carCour;
	this.fluxSour = fluxSour;
}
private final int EOF = 0;
public Scanner(String file1) throws ErreurLexicale {
    try {
        File file = new File(file1);
        this.fluxSour = new FileReader(file);
    }
    catch (Exception A) {
        throw new ErreurLexicale(CodesErr.FIC_VID_ERR);
    }
    this.MotsCles = new ArrayList<>();
}

public void initMotcles() {
	this.MotsCles.add(new Symboles(Tokens.IF_TOKEN,"if"));
	this.MotsCles.add(new Symboles(Tokens.BEGIN_TOKEN,"begin"));
	this.MotsCles.add(new Symboles(Tokens.WHILE_TOKEN,"while"));
	this.MotsCles.add(new Symboles(Tokens.THEN_TOKEN,"then"));
	this.MotsCles.add(new Symboles(Tokens.END_TOKEN,"end"));
	this.MotsCles.add(new Symboles(Tokens.DO_TOKEN,"do"));
	this.MotsCles.add(new Symboles(Tokens.WRITE_TOKEN,"write"));
	this.MotsCles.add(new Symboles(Tokens.READ_TOKEN,"read"));
	this.MotsCles.add(new Symboles(Tokens.CONST_TOKEN,"const"));
	this.MotsCles.add(new Symboles(Tokens.VAR_TOKEN,"var"));
	this.MotsCles.add(new Symboles(Tokens.END_TOKEN,"end"));
	this.MotsCles.add(new Symboles(Tokens.PROGRAM_TOKEN,"program"));
}
public void codageLex() {
	String nom1=symbCour.getNom();
	for(Symboles symb:MotsCles) {
		String nom2=symb.getNom();
		if(nom1.equalsIgnoreCase(nom2)) {
			symbCour.setToken(symb.getToken());
			return;
		}
	}
	symbCour.setToken(Tokens.ID_TOKEN);
}

 public void lireCar() throws IOException {
		if (fluxSour.ready())
			carCour=(char)fluxSour.read();
		else
			carCour=EOF;
	}
	
	public void lireMot() throws IOException {
		symbCour.setNom(symbCour.getNom()+carCour);
		lireCar();
		while(Character.isLetterOrDigit(carCour)) {
			symbCour.setNom(symbCour.getNom()+carCour);
			lireCar();
		}
		codageLex();
	}
	
	public void lireNombre() throws IOException { 
		symbCour.setNom(symbCour.getNom()+carCour);
		lireCar();
		while(Character.isDigit(carCour)) {
			symbCour.setNom(symbCour.getNom()+carCour);
			lireCar();
		}
		symbCour.setToken(Tokens.NUM_TOKEN);
	}
	
	public void symbSuiv() throws IOException, ErreurCompilation {
		symbCour=new Symboles();
		while(Character.isWhitespace(carCour))
			lireCar();
		if (Character.isLetter(carCour)) {
			lireMot();
			return;
		}
		if(Character.isDigit(carCour)) {
			lireNombre();
			return;
		}
	}
}


