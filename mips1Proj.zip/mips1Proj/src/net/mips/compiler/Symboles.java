package net.mips.compiler;

public class Symboles {
  private String nom;
  private Tokens token;
  int adresse;
  private ClasseIdf Classe;
 
 
  public Symboles( Tokens token,String nom) {
	super();
	this.nom = nom;
	this.token = token;
}
  public Symboles(Tokens token, String nom, ClasseIdf classe) {
      this.token = token;
      this.nom = nom;
      this.Classe = classe;
      this.adresse = -1;
  }
 public Symboles() {
	 this.nom="";
 }
public String getNom() {
	return nom;
}
public void setNom(String nom) {
	this.nom = nom;
}
public Tokens getToken() {
	return token;
}
public void setToken(Tokens token) {
	this.token = token;
	
	
}
public ClasseIdf getClasse() {
	return Classe;
}
public void setClasse(ClasseIdf classe) {
	Classe = classe;
}
public int getAdresse() {
	return adresse;
}
public void setAdresse(int adresse) {
	this.adresse = adresse;
}
  
}
