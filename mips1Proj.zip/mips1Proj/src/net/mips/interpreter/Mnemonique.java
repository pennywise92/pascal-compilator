package net.mips.interpreter;

public enum Mnemonique {
	 ADD, SUB, MUL, DIV, EQL, NEQ, GTR, LSS, GEQ, LEQ, PRN, INN, INT, LDI, LDA, LDV, STO, BRN, BZE, HLT, Num, EOF

}
